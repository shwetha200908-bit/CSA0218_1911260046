from flask import Flask, render_template, request, jsonify, session, redirect
import sqlite3
import hashlib
import os
import json

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-local-development-key")

DB = "code_detective.db"


def connect_db():
    return sqlite3.connect(DB)


def setup_database():
    con = connect_db()
    cur = con.cursor()

    cur.execute("""
    CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        progress TEXT DEFAULT '{}'
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS game_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER,
        activity TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    con.commit()
    con.close()


def log_activity(player_id, activity):
    con = connect_db()
    con.execute(
        "INSERT INTO game_history (player_id, activity) VALUES (?, ?)",
        (player_id, activity)
    )
    con.commit()
    con.close()


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


@app.route("/")
def home():
    return render_template("game.html")


@app.route("/api/register", methods=["POST"])
def register():
    data = request.json
    username = data.get("username", "").strip()
    password = data.get("password", "")

    if not username or len(password) < 6:
        return jsonify({"error": "Enter a username and password of at least 6 characters"}), 400

    con = connect_db()

    try:
        cur = con.cursor()
        cur.execute(
            "INSERT INTO players (username, password) VALUES (?, ?)",
            (username, hash_password(password))
        )
        player_id = cur.lastrowid
        con.commit()
        session["player_id"] = player_id
        session["username"] = username
        log_activity(player_id, "Registered")
        return jsonify({"success": True, "username": username})

    except sqlite3.IntegrityError:
        return jsonify({"error": "Username already exists"}), 409

    finally:
        con.close()


@app.route("/api/login", methods=["POST"])
def login():
    data = request.json
    username = data.get("username", "").strip()
    password = data.get("password", "")

    con = connect_db()
    cur = con.cursor()
    cur.execute(
        "SELECT id, password FROM players WHERE username=?",
        (username,)
    )
    player = cur.fetchone()
    con.close()

    if player and player[1] == hash_password(password):
        session["player_id"] = player[0]
        session["username"] = username
        log_activity(player[0], "Logged in")
        return jsonify({"success": True, "username": username})

    return jsonify({"error": "Invalid username or password"}), 401


@app.route("/api/me")
def me():
    if "player_id" not in session:
        return jsonify({"logged_in": False})

    con = connect_db()
    cur = con.cursor()
    cur.execute(
        "SELECT progress FROM players WHERE id=?",
        (session["player_id"],)
    )
    row = cur.fetchone()
    con.close()

    return jsonify({
        "logged_in": True,
        "username": session["username"],
        "progress": json.loads(row[0]) if row else {}
    })


@app.route("/api/progress", methods=["POST"])
def save_progress():
    if "player_id" not in session:
        return jsonify({"error": "Please log in"}), 401

    progress = request.json.get("progress", {})

    con = connect_db()
    con.execute(
        "UPDATE players SET progress=? WHERE id=?",
        (json.dumps(progress), session["player_id"])
    )
    con.commit()
    con.close()

    log_activity(session["player_id"], "Progress saved")
    return jsonify({"success": True})


@app.route("/api/event", methods=["POST"])
def event():
    if "player_id" not in session:
        return jsonify({"error": "Please log in"}), 401

    activity = request.json.get("activity", "Played game")
    log_activity(session["player_id"], activity)
    return jsonify({"success": True})


@app.route("/api/logout", methods=["POST"])
def logout():
    if "player_id" in session:
        log_activity(session["player_id"], "Logged out")

    session.clear()
    return jsonify({"success": True})


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "GET":
        return render_template("admin_login.html")

    username = request.form.get("username", "")
    password = request.form.get("password", "")

    con = connect_db()
    cur = con.cursor()
    cur.execute(
        "SELECT id FROM admins WHERE username=? AND password=?",
        (username, hash_password(password))
    )
    admin = cur.fetchone()
    con.close()

    if admin:
        session["admin"] = True
        return redirect("/admin")

    return "Invalid admin login"


@app.route("/admin")
def admin_dashboard():
    if not session.get("admin"):
        return redirect("/admin/login")

    con = connect_db()
    cur = con.cursor()

    cur.execute("SELECT id, username FROM players ORDER BY id DESC")
    players = cur.fetchall()

    cur.execute("""
        SELECT players.username, game_history.activity,
               game_history.created_at
        FROM game_history
        JOIN players ON players.id = game_history.player_id
        ORDER BY game_history.id DESC
        LIMIT 100
    """)
    history = cur.fetchall()

    con.close()

    return render_template(
        "admin.html",
        players=players,
        history=history
    )


@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None)
    return redirect("/admin/login")


def create_admin():
    con = connect_db()
    cur = con.cursor()

    username = "admin"
    password = "Admin@123"

    cur.execute(
        "INSERT OR IGNORE INTO admins (username, password) VALUES (?, ?)",
        (username, hash_password(password))
    )

    con.commit()
    con.close()


if __name__ == "__main__":
    setup_database()
    create_admin()
    app.run(debug=True)