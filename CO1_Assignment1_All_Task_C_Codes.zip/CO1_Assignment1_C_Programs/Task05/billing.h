#ifndef BILLING_H
#define BILLING_H

#define FIXED_CHARGE_PAISE 5000L

long calculate_bill(int units);

#endif
