CO5 Assignment 5 package

Contents:
- CO5_Assignment_5_Report.docx: formatted assignment report with aim, procedure, programs, expected outputs, results and screenshot placeholders.
- Task_B1_Recursion/: recursive power program
- Task_B3_Binary_File/: binary record update program
- Task_B4_Dynamic_Memory/: growable donor list program
- Screenshots/: place your genuine coding and output screenshots here.

Compile with GCC:
gcc filename.c -o program
./program

IMPORTANT:
The report's output sections show expected outputs. Replace screenshot placeholders with screenshots captured from your own compiler/IDE after running the code. Do not submit expected-output text as proof of execution.
