#include <stdio.h>
int calls = 0;
int verify_card(int has_card) {
    calls++;
    return has_card;
}
int main(void) {
    int senior_count = 0, eligible_count = 0, card_count = 0;
    int i, senior, eligible, card;
    /* Reproducible sample of 1,000 passengers */
    for (i = 0; i < 1000; i++) {
        senior = (i % 4 == 0);       /* 250 senior passengers */
        eligible = (i % 3 == 0);     /* 334 eligible passengers */
        card = (i % 10 == 0);        /* 100 card holders */
        senior_count += senior;
        eligible_count += eligible;
        card_count += card;
    }
    calls = 0;
    for (i = 0; i < 1000; i++) {
        senior = (i % 4 == 0);
        eligible = (i % 3 == 0);
        card = (i % 10 == 0);
        (void)((senior && eligible) || verify_card(card));
    }
    printf("Passengers: 1000\nSenior passengers: %d\nEligible-class passengers: %d\nCard holders: %d\n",
           senior_count, eligible_count, card_count);
    printf("Verification calls, (senior && eligible) || verify_card: %d\n", calls);

    calls = 0;
    for (i = 0; i < 1000; i++) {
        senior = (i % 4 == 0);
        eligible = (i % 3 == 0);
        card = (i % 10 == 0);
        (void)(verify_card(card) || (senior && eligible));
    }
    printf("Verification calls, verify_card || (senior && eligible): %d\n", calls);
    printf("Note: || and && short-circuit; | and & evaluate both operands.\n");
    return 0;
}