#include <stdio.h>
unsigned long basic_checks = 0, improved_checks = 0;
int basic_prime(unsigned long n) {
    basic_checks = 0;
    if (n < 2) return 0;
    for (unsigned long i = 2; i < n; i++) {
        basic_checks++;
        if (n % i == 0) return 0;
    }
    return 1;
}
int improved_prime(unsigned long n) {
    improved_checks = 0;
    if (n < 2) return 0;
    if (n % 2 == 0) {
        improved_checks++;
        return n == 2;
    }
    for (unsigned long i = 3; i <= n / i; i += 2) {
        improved_checks++;
        if (n % i == 0) return 0;
    }
    return 1;
}
int main(void) {
    unsigned long values[] = {97, 100, 7919, 1000003};
    for (int k = 0; k < 4; k++) {
        unsigned long n = values[k];
        int a = basic_prime(n);
        int b = improved_prime(n);
        printf("%lu: basic=%s checks=%lu | redesigned=%s checks=%lu\n",
               n, a ? "prime" : "not prime", basic_checks,
               b ? "prime" : "not prime", improved_checks);
    }
    return 0;
}